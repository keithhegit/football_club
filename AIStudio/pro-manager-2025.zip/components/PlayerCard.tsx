
// This component has been deprecated in favor of PlayerProfileCard.tsx
// Keeping file empty or minimal to avoid build errors if referenced elsewhere before full cleanup.
import React from 'react';
export const PlayerCard = () => <div>Deprecated</div>;
